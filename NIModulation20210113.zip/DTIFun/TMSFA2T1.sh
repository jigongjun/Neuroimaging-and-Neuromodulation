flirt -in FA -ref dataB  -out FAinT1 -omat FA2T1.mat
convert_xfm -omat T12FA.mat -inverse FA2T1.mat
