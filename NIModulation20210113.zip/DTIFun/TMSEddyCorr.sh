eddy_correct dataB.nii dataBC.nii.gz 0 
   
 
