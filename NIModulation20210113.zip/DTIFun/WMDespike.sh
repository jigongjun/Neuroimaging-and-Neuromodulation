   3dDespike -prefix fundata.nii fundata.nii
