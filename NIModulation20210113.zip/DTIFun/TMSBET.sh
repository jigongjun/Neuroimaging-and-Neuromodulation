   bet data.nii.gz dataB.nii.gz -F -g 0 -n -m
