dtifit -k dataBC.nii.gz -o dataBCF -m dataB_mask -r bvec -b bval

